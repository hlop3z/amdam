# Test Fullstack Functions

## Backend & Frontend Development

### Installing

```
python -m pip install https://github.com/hlop3z/amdam/raw/master/dist/amdam-0.0.1.tar.gz
```
